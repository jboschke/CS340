# animal_shelter.py
# CRUD wrapper for AAC.animals (MongoDB)

from typing import Any, Dict, List, Optional
from pymongo import MongoClient
from pymongo.errors import PyMongoError


class AnimalShelter:
    """
    Reusable helper for the AAC 'animals' collection.
    Methods must match rubric:
      - create(data: dict) -> bool
      - read(query: dict, projection: dict|None = None, limit: int = 0) -> List[dict]
      - update(query: dict, new_values: dict, many: bool = False) -> int (num modified)
      - delete(query: dict, many: bool = False) -> int (num deleted)
    """

    def __init__(
        self,
        user: str = "aacuser",
        pwd: str = "uT9~kV3-Pw1_Lz7.qR5nY2sB8",                # <-- put your aacuser password here
        host: str = "nv-desktop-services.apporto.com",
        port: int = 32508,
        db: str = "AAC",
        col: str = "animals",
    ) -> None:
        uri = f"mongodb://{user}:{pwd}@{host}:{port}/?authSource=admin"
        self.client: MongoClient = MongoClient(uri)
        self.collection = self.client[db][col]

    # -------------------- C (Create) --------------------
    def create(self, data: Dict[str, Any]) -> bool:
        """Insert ONE document. Return True if acknowledged, else False."""
        if not data or not isinstance(data, dict):
            raise ValueError("create(): data must be a non-empty dict")
        try:
            return self.collection.insert_one(data).acknowledged
        except PyMongoError as e:
            print("[create] Mongo error:", e)
            return False

    # -------------------- R (Read) ----------------------
    def read(
        self,
        query: Optional[Dict[str, Any]] = None,
        projection: Optional[Dict[str, int]] = None,
        limit: int = 0,
    ) -> List[Dict[str, Any]]:
        """Return a list of matching documents (empty list if none)."""
        query = query or {}
        cursor = self.collection.find(query, projection)
        if limit and isinstance(limit, int) and limit > 0:
            cursor = cursor.limit(limit)
        return list(cursor)

    # -------------------- U (Update) --------------------
    def update(self, query: Dict[str, Any], new_values: Dict[str, Any], many: bool = False) -> int:
        """
        Update fields using $set. Return number of documents modified.
        Example: update({"animal_id":"A123"}, {"breed":"Beagle"})
        """
        if not query or not new_values:
            raise ValueError("update(): query and new_values must be non-empty dicts")
        try:
            op = self.collection.update_many if many else self.collection.update_one
            result = op(query, {"$set": new_values})
            return int(result.modified_count)
        except PyMongoError as e:
            print("[update] Mongo error:", e)
            return 0

    # -------------------- D (Delete) --------------------
    def delete(self, query: Dict[str, Any], many: bool = False) -> int:
        """
        Delete documents matching query. Return number of documents deleted.
        Example: delete({"animal_id":"TEST9999"})
        """
        if not query:
            raise ValueError("delete(): query must be a non-empty dict")
        try:
            op = self.collection.delete_many if many else self.collection.delete_one
            result = op(query)
            return int(result.deleted_count)
        except PyMongoError as e:
            print("[delete] Mongo error:", e)
            return 0
